import { faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import classNames from 'classnames/bind';
import styles from './AccountItem.module.scss';
const cx = classNames.bind(styles);



function AccountItem() {
    return ( 
        <div className={cx('wrapper')}>
            <img className={cx('avatar')} src="https://p16-sign-va.tiktokcdn.com/tos-maliva-avt-0068/9f57ce11d331b3e90da22cbaaab86d4d~c5_100x100.jpeg?x-expires=1665046800&x-signature=lMZara0Zmg%2BiOCVldL4hYgiQJWw%3D" alt="avatar" />
            <div className={cx('info')}>
                <h4 className={cx('name')}>
                    <span>shinee09</span>
                    <FontAwesomeIcon className={cx('check')} icon={faCheckCircle}/>
                </h4>
                <span className={cx('username')}>shinee9</span>
            </div>
        </div>
     );
}

export default AccountItem;