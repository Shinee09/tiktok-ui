function Upload() {
    return <h2>Upload Page</h2>;
}

export default Upload;