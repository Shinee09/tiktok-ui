const images = {
    logo: require('~/assets/images/logo.svg').default
}
export default images